# Release checklist

Use this checklist before tagging or publishing a release.

## Package contents

- Include the repository source, launchers, license, changelog, documentation, and `5nqy_devbot-extension/` directory.
- Do not include `logs/`, Python bytecode/cache folders, local credentials, browser profiles, or machine-specific configuration.
- For Chrome/Edge unpacked install, select the `5nqy_devbot-extension/` folder.
- For a downloadable source ZIP, download/extract the complete repository archive before running the bridge launcher.

## Local checks

From `5nqy_devbot-extension/`:

```sh
node --check providers/claude.js
node test-parser.js
node test-chatgpt.js
```

From the repository root, if Python 3.9+ and `websockets` are installed:

```sh
python -m py_compile bridge.py launch_studio_mcp.py
python -m json.tool config.json
python -m json.tool 5nqy_devbot-extension/manifest.json
```

Also smoke-test the unpacked extension in Chrome or Edge, launch the bridge on a clean machine/profile, and verify Roblox Studio reports tools when a place is open and its MCP server is enabled. Site DOM compatibility and Studio MCP availability cannot be fully proved by the automated tests alone.

## Before publishing

- Update the version in `5nqy_devbot-extension/manifest.json` and `bridge.py` together.
- Add release notes at the top of `CHANGELOG.md`.
- Confirm the README installation steps and support links are current.
- Review the staged files and ensure no secrets, logs or local machine data are included.
- Create a GitHub release only after the package checks and manual smoke tests pass.
