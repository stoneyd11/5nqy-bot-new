# 5nqy_devbot 2.1.2 — AI Developer Assistant

5nqy_devbot is a Chromium browser extension with a local Python bridge for AI-assisted development workflows and Roblox Studio automation. It works through the AI chat sites you are already signed in to; it does not require an AI API key.

> **Compatibility note:** Chat providers change their websites frequently. Claude, ChatGPT, DeepSeek, Gemini, Kimi, GLM / Z.ai, Qwen, Arena and Meta AI have dedicated adapters. Mistral Vibe, Grok, Perplexity, Microsoft Copilot, Poe, HuggingChat, OpenRouter and MiniMax use a generic compatibility adapter, so support on those sites is best-effort and may vary. See [provider details](5nqy_devbot-extension/README.md).

## What’s included

- Chromium extension for supported AI chat sites, with provider-specific response handling.
- Local bridge that connects the extension to Roblox Studio’s built-in MCP server.
- Studio tooling for inspecting and editing project scripts and objects, running Luau, and verifying changes.
- Optional Ultra AI multi-agent workflow; it opens browser tabs for selected AI providers and stores job progress locally.
- Settings for enabled providers, appearance, automation and workflow preferences.

## Requirements

- Google Chrome or Microsoft Edge (Chromium-based).
- Python 3.9 or newer and an internet connection for the first bridge launch (the launcher installs the small `websockets` dependency if needed).
- Roblox Studio for Studio automation. Open a place and enable **Studio as MCP server** in **Assistant Settings → MCP Servers**.
- A signed-in account on whichever AI chat site you use.

## Install the browser extension

1. Download the repository ZIP from GitHub and **extract the entire ZIP** to a normal folder. Do not run files from inside the ZIP preview.
2. In Chrome, open `chrome://extensions`; in Edge, open `edge://extensions`.
3. Turn on **Developer mode**.
4. Select **Load unpacked** and choose the `5nqy_devbot-extension` folder from the extracted package.
5. Open the extension’s **Settings** page to choose providers and preferences.
6. Open a supported AI chat site and sign in. You may need to refresh tabs that were already open when the extension was installed or updated.

The extension does not bundle, proxy or replace any provider’s AI service. Each site uses its own account, limits and terms.

## Start the local bridge

Keep the downloaded package extracted as a whole so `bridge.py`, `config.json`, and the launcher stay together.

### Windows
Double-click `start.bat`. Keep the terminal window open while using the bridge. It checks for Python and `websockets`, then starts the bridge and Roblox Studio MCP connection.

### macOS / Linux
Run `MacOS_Start.command` from the extracted folder. If macOS blocks the first launch, use Finder’s context menu to open the file, or run it from Terminal. Keep its terminal window open while using the bridge.

The bridge only listens on `127.0.0.1` on port `17613` by default; it is intended for local use on your own computer. Its diagnostic logs are written to `logs/` and are not included in the source package.

## Use with Roblox Studio

1. Start the bridge using the launcher for your operating system.
2. Open a place in Roblox Studio.
3. In Studio, go to **Assistant Settings → MCP Servers** and enable **Studio as MCP server**. Studio may disable this after an update; check the setting if the bridge reports Studio offline.
4. Refresh the AI site tab, start a new 5nqy_devbot session, and ask for your task.

The extension’s AI runs inside the provider’s website. The bridge and Studio must remain open for local Studio commands to work. Keep project backups and review important changes in Studio before publishing a Roblox experience.

## Troubleshooting

- **Extension does not appear:** confirm that you loaded the `5nqy_devbot-extension` subfolder and that Developer mode is enabled. Check `chrome://extensions` or `edge://extensions` for an error, fix it, then reload the extension.
- **AI site tab does not show the extension:** refresh the tab after loading/reloading the extension; check that the current site URL is listed in the [provider documentation](5nqy_devbot-extension/README.md).
- **Bridge offline:** run `start.bat` or `MacOS_Start.command` from the fully extracted package, leave its terminal open, and confirm the launcher reports the bridge listening on port `17613`.
- **Bridge starts but Roblox is offline or has zero tools:** open a place in Studio and enable **Studio as MCP server** in **Assistant Settings → MCP Servers**. After a Studio update, toggle the setting off and on again.
- **A provider stops working:** its website may have changed. Reload the tab and extension first; if the problem persists, report the provider, browser, extension version and a short error description. Do not include passwords, session cookies, API keys or private project data.

## Privacy and safety

- The extension reads the supported AI chat page to detect assistant replies and issue commands when you explicitly start its workflow. AI-provider conversations are handled by that provider under its own policies.
- The local bridge is bound to loopback (`127.0.0.1`), not a public network interface.
- Settings, job history and session workflow metadata are stored in the browser’s local extension storage. The extension does not request AI API keys.
- Studio automation can make real changes to the currently open place. Review edits, use backups/version history, and do not run commands you do not understand.
- Use 5nqy_devbot only on accounts and projects you are authorized to access. Follow the terms of the browser, AI providers and Roblox.

## Project layout

- `5nqy_devbot-extension/` — browser extension, provider adapters and tests.
- `bridge.py` — local WebSocket bridge and MCP process manager.
- `launch_studio_mcp.py` — locates the installed Roblox Studio MCP executable.
- `config.json` — local MCP server configuration.
- `start.bat` — Windows launcher.
- `MacOS_Start.command` — macOS/Linux launcher.
- `CHANGELOG.md` — release history.
- `LICENSE` — project license.

## Validate locally

With Node.js installed, run:

```sh
cd 5nqy_devbot-extension
node test-parser.js
node test-chatgpt.js
```

The bridge requires Python 3.9+ and `websockets`; the provided launchers check/install the dependency as needed. Automated tests do not replace a live browser and Roblox Studio smoke test.

## Support

For bug reports, include the extension version, browser/OS, affected AI provider and the exact error text. Remove personal information and secrets from logs before sharing them. The maintainer's public GitHub profile is [github.com/sebattfg](https://github.com/sebattfg); confirm the current repository and Issues page there before filing a report.
