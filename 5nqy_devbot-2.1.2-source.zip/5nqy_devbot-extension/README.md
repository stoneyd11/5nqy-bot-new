# 5nqy_devbot 2.1.2 — Browser Extension

This folder is the unpacked Chromium extension. Load this exact folder in Chrome or Edge using **Developer mode → Load unpacked**. For the complete setup, bridge requirements, Roblox Studio connection, troubleshooting and privacy notes, see the [project README](../README.md).

## Providers

**Dedicated adapters:** Claude, ChatGPT, DeepSeek, Gemini, Kimi, GLM / Z.ai, Qwen, Arena and Meta AI.

**Compatibility adapters:** Mistral Vibe, Grok, Perplexity, Microsoft Copilot, Poe, HuggingChat, OpenRouter and MiniMax use `providers/generic.js`. They are best-effort and may not work if a site's interface changes. MiMo appears as a model catalog/routing option, not a separate chat-site adapter.

Provider sites can change without notice. A provider’s current website DOM is not a stable public API; availability and behavior can vary by account, region and site version.

## Roblox Studio

Roblox Studio is the primary MCP target, connected by the local bridge in the repository root. Studio must be open with a place loaded and **Studio as MCP server** enabled. Automation can change the currently open place; review edits and keep backups.

## Tests

Run from this directory with Node.js:

```sh
node test-parser.js
node test-chatgpt.js
```
